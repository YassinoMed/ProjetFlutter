import 'package:flutter/foundation.dart';

import '../models/country.dart';
import '../models/visited_city.dart';
import '../services/restcountries_service.dart';
import '../services/storage_service.dart';

class PaysProvider extends ChangeNotifier {
  PaysProvider({
    required RestCountriesService restCountriesService,
    required StorageService storageService,
  })  : _restCountriesService = restCountriesService,
        _storageService = storageService;

  final RestCountriesService _restCountriesService;
  final StorageService _storageService;

  List<Country> _countries = const [];
  List<VisitedCity> _visitedCities = const [];
  bool _isLoadingCountries = false;
  bool _isLoadingVisitedCities = false;
  bool _isSaving = false;
  String? _countriesError;

  List<Country> get countries => _countries;
  List<VisitedCity> get visitedCities => _visitedCities;
  bool get isLoadingCountries => _isLoadingCountries;
  bool get isLoadingVisitedCities => _isLoadingVisitedCities;
  bool get isSaving => _isSaving;
  String? get countriesError => _countriesError;

  Future<void> initialize() async {
    await loadVisitedCities();
    await loadCountries();
  }

  Future<void> loadVisitedCities() async {
    _isLoadingVisitedCities = true;
    notifyListeners();

    _visitedCities = await _storageService.getVisitedCities();
    _isLoadingVisitedCities = false;
    notifyListeners();
  }

  Future<void> loadCountries() async {
    _isLoadingCountries = true;
    _countriesError = null;
    notifyListeners();

    try {
      _countries = await _restCountriesService.fetchAllCountries();
    } on RestCountriesException catch (error) {
      _countriesError = error.message;
    } catch (_) {
      _countriesError = 'Erreur inattendue pendant le chargement des pays.';
    } finally {
      _isLoadingCountries = false;
      notifyListeners();
    }
  }

  Iterable<Country> filterCountries(String query) {
    final source = query.trim().isEmpty
        ? _countries
        : _countries.where((country) => country.matchesQuery(query));

    return source.take(30);
  }

  Country? findCountryByInput(String input) {
    final normalizedInput = Country.normalizeText(input);
    if (normalizedInput.isEmpty) {
      return null;
    }

    for (final country in _countries) {
      final exactTerms = [
        country.displayName,
        country.officialDisplayName,
        country.commonName,
        country.officialName,
        country.code,
      ];

      final isExactMatch = exactTerms.any(
        (term) => Country.normalizeText(term) == normalizedInput,
      );
      if (isExactMatch) {
        return country;
      }
    }

    return null;
  }

  Country? findCountryByCode(String? code) {
    final normalizedCode = code?.trim().toUpperCase();
    if (normalizedCode == null || normalizedCode.isEmpty) {
      return null;
    }

    return _countries
        .where((country) => country.code == normalizedCode)
        .firstOrNull;
  }

  Country? findCountryByName(String name) {
    final normalizedName = Country.normalizeText(name);
    if (normalizedName.isEmpty) {
      return null;
    }

    return _countries.where((country) {
      return country.searchTerms.any(
        (term) => Country.normalizeText(term) == normalizedName,
      );
    }).firstOrNull;
  }

  Future<void> addVisitedCity({
    required String cityName,
    required Country country,
  }) async {
    final cleanCityName = cityName.trim();
    if (cleanCityName.isEmpty) {
      throw ArgumentError('Le nom de la ville est obligatoire.');
    }

    // Vérification des doublons
    final normalizedCity = Country.normalizeText(cleanCityName);
    final normalizedCountry = Country.normalizeText(country.displayName);
    final isDuplicate = _visitedCities.any((city) =>
        Country.normalizeText(city.cityName) == normalizedCity &&
        Country.normalizeText(city.countryName) == normalizedCountry);
    if (isDuplicate) {
      throw ArgumentError(
        '$cleanCityName, ${country.displayName} existe déjà dans votre carnet.',
      );
    }

    _isSaving = true;
    notifyListeners();

    final city = VisitedCity(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      cityName: cleanCityName,
      countryName: country.displayName,
      countryCode: country.code,
      createdAt: DateTime.now(),
    );

    try {
      await _storageService.saveVisitedCity(city);
      _visitedCities = await _storageService.getVisitedCities();
    } finally {
      _isSaving = false;
      notifyListeners();
    }
  }

  Future<void> deleteVisitedCity(VisitedCity city) async {
    await _storageService.deleteVisitedCity(city.id);
    _visitedCities = await _storageService.getVisitedCities();
    notifyListeners();
  }

  Future<Country> loadCountryDetails({
    required String countryName,
    String? countryCode,
  }) async {
    final localCountry =
        findCountryByCode(countryCode) ?? findCountryByName(countryName);
    if (localCountry != null) {
      return localCountry;
    }

    if (countryCode != null && countryCode.trim().isNotEmpty) {
      return _restCountriesService.fetchCountryByCode(countryCode);
    }

    return _restCountriesService.fetchCountryByName(countryName);
  }
}
