import 'package:path/path.dart' as path;
import 'package:sqflite/sqflite.dart';

Future<String> resolveDatabasePath(String databaseName) async {
  final databasesPath = await getDatabasesPath();
  return path.join(databasesPath, databaseName);
}
