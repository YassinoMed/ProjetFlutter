import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/country.dart';

class RestCountriesException implements Exception {
  const RestCountriesException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class RestCountriesService {
  RestCountriesService({http.Client? client})
      : _client = client ?? http.Client();

  static const _host = 'restcountries.com';
  static const _listFields = 'name,translations,cca2';

  final http.Client _client;

  Future<List<Country>> fetchAllCountries() async {
    final uri = Uri.https(_host, '/v3.1/all', {'fields': _listFields});

    try {
      final response =
          await _client.get(uri).timeout(const Duration(seconds: 15));
      _throwIfInvalid(response);

      final decoded = jsonDecode(response.body);
      if (decoded is! List) {
        throw const RestCountriesException('Réponse API inattendue.');
      }

      final countries = decoded
          .whereType<Map>()
          .map((item) => Country.fromJson(Map<String, dynamic>.from(item)))
          .where((country) => country.commonName.isNotEmpty)
          .toList()
        ..sort(
          (a, b) => Country.normalizeText(
            a.displayName,
          ).compareTo(Country.normalizeText(b.displayName)),
        );

      return countries;
    } on RestCountriesException {
      rethrow;
    } on TimeoutException {
      throw const RestCountriesException(
        'Le chargement des pays a pris trop de temps. Vérifiez la connexion.',
      );
    } catch (_) {
      throw const RestCountriesException(
        'Impossible de charger les pays. Vérifiez la connexion internet.',
      );
    }
  }

  Future<Country> fetchCountryByCode(String code) async {
    final cleanCode = code.trim();
    if (cleanCode.isEmpty) {
      throw const RestCountriesException('Code pays invalide.');
    }

    final uri = Uri(
      scheme: 'https',
      host: _host,
      pathSegments: ['v3.1', 'alpha', cleanCode],
    );
    return _fetchSingleCountry(uri);
  }

  Future<Country> fetchCountryByName(String name) async {
    final cleanName = name.trim();
    if (cleanName.isEmpty) {
      throw const RestCountriesException('Nom du pays invalide.');
    }

    final uri = Uri(
      scheme: 'https',
      host: _host,
      pathSegments: ['v3.1', 'name', cleanName],
    );
    return _fetchSingleCountry(uri);
  }

  Future<Country> _fetchSingleCountry(Uri uri) async {
    try {
      final response =
          await _client.get(uri).timeout(const Duration(seconds: 15));
      _throwIfInvalid(response);

      final decoded = jsonDecode(response.body);
      if (decoded is List && decoded.isNotEmpty && decoded.first is Map) {
        return Country.fromJson(
            Map<String, dynamic>.from(decoded.first as Map));
      }
      if (decoded is Map) {
        return Country.fromJson(Map<String, dynamic>.from(decoded));
      }

      throw const RestCountriesException('Pays introuvable.');
    } on RestCountriesException {
      rethrow;
    } on TimeoutException {
      throw const RestCountriesException(
        'Le chargement du pays a pris trop de temps. Vérifiez la connexion.',
      );
    } catch (_) {
      throw const RestCountriesException(
        'Impossible de charger les détails du pays.',
      );
    }
  }

  void _throwIfInvalid(http.Response response) {
    if (response.statusCode == 200) {
      return;
    }

    if (response.statusCode == 404) {
      throw RestCountriesException(
        'Pays introuvable.',
        statusCode: response.statusCode,
      );
    }

    throw RestCountriesException(
      'Erreur API RestCountries (${response.statusCode}).',
      statusCode: response.statusCode,
    );
  }

  void dispose() {
    _client.close();
  }
}
