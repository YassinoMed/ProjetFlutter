import 'package:sqflite/sqflite.dart';

import '../models/visited_city.dart';
import 'database_path.dart';

class StorageService {
  static const databaseName = 'atelier7_pays.db';
  static const visitedCitiesTable = 'visited_cities';

  Database? _database;

  Future<void> init() async {
    final databasePath = await resolveDatabasePath(databaseName);

    _database = await openDatabase(
      databasePath,
      version: 1,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE $visitedCitiesTable (
            id TEXT PRIMARY KEY,
            cityName TEXT NOT NULL,
            countryName TEXT NOT NULL,
            countryCode TEXT,
            createdAt TEXT NOT NULL
          )
        ''');
      },
    );
  }

  Future<List<VisitedCity>> getVisitedCities() async {
    final rows = await _db.query(
      visitedCitiesTable,
      orderBy: 'createdAt DESC',
    );

    return rows.map((json) => VisitedCity.fromJson(json)).toList();
  }

  Future<List<Map<String, Object?>>> getVisitedCitiesJson() {
    return _db.query(
      visitedCitiesTable,
      orderBy: 'createdAt DESC',
    );
  }

  Future<void> saveVisitedCity(VisitedCity city) async {
    await _db.insert(
      visitedCitiesTable,
      city.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteVisitedCity(String id) async {
    await _db.delete(
      visitedCitiesTable,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Database get _db {
    final database = _database;
    if (database == null) {
      throw StateError('La base SQLite n’est pas initialisée.');
    }
    return database;
  }
}
