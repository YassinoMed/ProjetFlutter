class Country {
  const Country({
    required this.code,
    required this.commonName,
    required this.officialName,
    required this.capitals,
    required this.languages,
    required this.region,
    required this.subregion,
    required this.area,
    required this.population,
    required this.flagPngUrl,
    required this.flagSvgUrl,
    required this.flagAlt,
    this.frenchCommonName,
    this.frenchOfficialName,
    this.nativeCommonName,
    this.nativeOfficialName,
    this.borders = const [],
  });

  final String code;
  final String commonName;
  final String officialName;
  final String? frenchCommonName;
  final String? frenchOfficialName;
  final List<String> capitals;
  final Map<String, String> languages;
  final String region;
  final String subregion;
  final double area;
  final int population;
  final String flagPngUrl;
  final String flagSvgUrl;
  final String flagAlt;
  final String? nativeCommonName;
  final String? nativeOfficialName;
  final List<String> borders;

  String get displayName {
    final frenchName = frenchCommonName?.trim();
    if (frenchName != null && frenchName.isNotEmpty) {
      return frenchName;
    }
    return commonName;
  }

  String get officialDisplayName {
    final frenchName = frenchOfficialName?.trim();
    if (frenchName != null && frenchName.isNotEmpty) {
      return frenchName;
    }
    return officialName;
  }

  List<String> get searchTerms {
    return <String?>[
      displayName,
      officialDisplayName,
      commonName,
      officialName,
      frenchCommonName,
      frenchOfficialName,
      nativeCommonName,
      nativeOfficialName,
      code,
    ].whereType<String>().where((term) => term.trim().isNotEmpty).toList();
  }

  bool matchesQuery(String query) {
    final normalizedQuery = normalizeText(query);
    if (normalizedQuery.isEmpty) {
      return true;
    }

    return searchTerms.any(
      (term) => normalizeText(term).contains(normalizedQuery),
    );
  }

  factory Country.fromJson(Map<String, dynamic> json) {
    final name = _asMap(json['name']);
    final nativeNames = _asMap(name['nativeName']);
    final nativeName = _preferredNativeName(nativeNames);
    final translations = _asMap(json['translations']);
    final frenchTranslation = _asMap(translations['fra']);
    final flags = _asMap(json['flags']);
    final rawLanguages = _asMap(json['languages']);

    return Country(
      code: (json['cca2'] as String? ?? '').toUpperCase(),
      commonName: name['common'] as String? ?? '',
      officialName: name['official'] as String? ?? '',
      frenchCommonName: frenchTranslation['common'] as String?,
      frenchOfficialName: frenchTranslation['official'] as String?,
      nativeCommonName: nativeName['common'] as String?,
      nativeOfficialName: nativeName['official'] as String?,
      capitals: _asStringList(json['capital']),
      languages: rawLanguages.map(
        (key, value) => MapEntry(key, value.toString()),
      ),
      region: json['region'] as String? ?? '',
      subregion: json['subregion'] as String? ?? '',
      area: (json['area'] as num?)?.toDouble() ?? 0,
      population: (json['population'] as num?)?.toInt() ?? 0,
      flagPngUrl: flags['png'] as String? ?? '',
      flagSvgUrl: flags['svg'] as String? ?? '',
      flagAlt: flags['alt'] as String? ?? '',
      borders: _asStringList(json['borders']),
    );
  }

  static String normalizeText(String input) {
    const replacements = {
      'à': 'a',
      'á': 'a',
      'â': 'a',
      'ã': 'a',
      'ä': 'a',
      'å': 'a',
      'ā': 'a',
      'ă': 'a',
      'ą': 'a',
      'ç': 'c',
      'ć': 'c',
      'č': 'c',
      'ď': 'd',
      'đ': 'd',
      'è': 'e',
      'é': 'e',
      'ê': 'e',
      'ë': 'e',
      'ē': 'e',
      'ė': 'e',
      'ę': 'e',
      'ě': 'e',
      'ì': 'i',
      'í': 'i',
      'î': 'i',
      'ï': 'i',
      'ī': 'i',
      'ł': 'l',
      'ñ': 'n',
      'ń': 'n',
      'ò': 'o',
      'ó': 'o',
      'ô': 'o',
      'õ': 'o',
      'ö': 'o',
      'ō': 'o',
      'ő': 'o',
      'ù': 'u',
      'ú': 'u',
      'û': 'u',
      'ü': 'u',
      'ū': 'u',
      'ů': 'u',
      'ű': 'u',
      'ý': 'y',
      'ÿ': 'y',
      'ž': 'z',
      'ź': 'z',
      'ż': 'z',
    };

    final buffer = StringBuffer();
    for (final rune in input.toLowerCase().runes) {
      final character = String.fromCharCode(rune);
      buffer.write(replacements[character] ?? character);
    }

    return buffer
        .toString()
        .replaceAll(RegExp(r'[^\w\s-]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static Map<String, dynamic> _asMap(Object? value) {
    if (value is Map) {
      return value.map((key, value) => MapEntry(key.toString(), value));
    }
    return <String, dynamic>{};
  }

  static List<String> _asStringList(Object? value) {
    if (value is List) {
      return value.whereType<String>().toList();
    }
    return const <String>[];
  }

  static Map<String, dynamic> _preferredNativeName(
    Map<String, dynamic> nativeNames,
  ) {
    final arabicName = _asMap(nativeNames['ara']);
    if (arabicName.isNotEmpty) {
      return arabicName;
    }

    for (final value in nativeNames.values) {
      final nativeName = _asMap(value);
      if (nativeName.isNotEmpty) {
        return nativeName;
      }
    }

    return const <String, dynamic>{};
  }
}
