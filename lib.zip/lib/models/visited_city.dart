class VisitedCity {
  const VisitedCity({
    required this.id,
    required this.cityName,
    required this.countryName,
    required this.createdAt,
    this.countryCode,
  });

  final String id;
  final String cityName;
  final String countryName;
  final String? countryCode;
  final DateTime createdAt;

  /// Derive flag URL from country code (no need to store it).
  String? get flagUrl {
    final code = countryCode?.trim().toLowerCase();
    if (code == null || code.isEmpty) return null;
    return 'https://flagcdn.com/w80/$code.png';
  }

  Map<String, Object?> toJson() {
    return {
      'id': id,
      'cityName': cityName,
      'countryName': countryName,
      'countryCode': countryCode,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory VisitedCity.fromJson(Map<String, Object?> json) {
    return VisitedCity(
      id: json['id'] as String,
      cityName: json['cityName'] as String,
      countryName: json['countryName'] as String,
      countryCode: json['countryCode'] as String?,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }
}
