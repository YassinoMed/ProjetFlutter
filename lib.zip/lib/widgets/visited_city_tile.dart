import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../models/visited_city.dart';

class VisitedCityTile extends StatelessWidget {
  const VisitedCityTile({
    required this.city,
    required this.onTap,
    required this.onDelete,
    super.key,
  });

  final VisitedCity city;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);
    if (diff.inMinutes < 1) return "A l'instant";
    if (diff.inHours < 1) return 'Il y a ${diff.inMinutes} min';
    if (diff.inDays < 1) return 'Il y a ${diff.inHours}h';
    if (diff.inDays == 1) return 'Hier';
    if (diff.inDays < 7) return 'Il y a ${diff.inDays} jours';
    return DateFormat('dd/MM/yyyy').format(date);
  }

  @override
  Widget build(BuildContext context) {
    final flagUrl = city.flagUrl;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          splashColor: const Color(0xFF1B4DFF).withValues(alpha: 0.06),
          highlightColor: const Color(0xFF1B4DFF).withValues(alpha: 0.03),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF1B4DFF).withValues(alpha: 0.1),
                        const Color(0xFF00C9A7).withValues(alpha: 0.1),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(13),
                    child: flagUrl != null
                        ? CachedNetworkImage(
                            imageUrl: flagUrl,
                            fit: BoxFit.cover,
                            placeholder: (_, _) => const Icon(
                                Icons.flag_rounded,
                                color: Color(0xFF1B4DFF),
                                size: 22),
                            errorWidget: (_, _, _) => const Icon(
                                Icons.flag_rounded,
                                color: Color(0xFF1B4DFF),
                                size: 22),
                          )
                        : const Icon(Icons.location_on_rounded,
                            color: Color(0xFF1B4DFF), size: 22),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(city.cityName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 15,
                              color: Color(0xFF152033),
                              letterSpacing: -0.2)),
                      const SizedBox(height: 3),
                      Row(children: [
                        const Icon(Icons.flag_rounded,
                            size: 13, color: Color(0xFF7B8BA5)),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(city.countryName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Color(0xFF1B4DFF),
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(width: 6),
                        Text('· ${_formatDate(city.createdAt)}',
                            style: const TextStyle(
                                color: Color(0xFFABB5C5),
                                fontSize: 11,
                                fontWeight: FontWeight.w500)),
                      ]),
                    ],
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(Icons.chevron_right_rounded,
                    color: Color(0xFFCBD2DE), size: 22),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
