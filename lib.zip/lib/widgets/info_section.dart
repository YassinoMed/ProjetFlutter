import 'package:flutter/material.dart';

class InfoSection extends StatelessWidget {
  const InfoSection({
    required this.title,
    required this.icon,
    required this.rows,
    super.key,
  });

  final String title;
  final IconData icon;
  final List<InfoRowData> rows;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: colors.primary.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: colors.primary, size: 22),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: const Color(0xFF152033),
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.2,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...rows.map((row) => _InfoRow(row: row)),
        ],
      ),
    );
  }
}

class InfoRowData {
  const InfoRowData(this.label, this.value, [this.icon]);

  final String label;
  final String value;
  final IconData? icon;
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.row});

  final InfoRowData row;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (row.icon != null) ...[
            Icon(
              row.icon,
              size: 16,
              color: const Color(0xFF7B8BA5),
            ),
            const SizedBox(width: 8),
          ],
          SizedBox(
            width: row.icon != null ? 104 : 120,
            child: Text(
              row.label,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: const Color(0xFF7B8BA5),
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              row.value,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: const Color(0xFF152033),
                    fontWeight: FontWeight.w700,
                    height: 1.3,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
