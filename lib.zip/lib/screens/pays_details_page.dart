import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show NumberFormat;
import 'package:provider/provider.dart';

import '../models/country.dart';
import '../providers/pays_provider.dart';
import '../services/restcountries_service.dart';
import '../widgets/app_error_banner.dart';
import '../widgets/info_section.dart';

class PaysDetailsPage extends StatefulWidget {
  const PaysDetailsPage({
    required this.countryName,
    this.countryCode,
    super.key,
  });

  final String countryName;
  final String? countryCode;

  @override
  State<PaysDetailsPage> createState() => _PaysDetailsPageState();
}

class _PaysDetailsPageState extends State<PaysDetailsPage> {
  late Future<Country> _countryFuture;

  @override
  void initState() {
    super.initState();
    _countryFuture = _loadCountry();
  }

  /// Simplified loading (#12): use provider to find best identifier, then fetch.
  Future<Country> _loadCountry() async {
    final provider = context.read<PaysProvider>();
    final service = context.read<RestCountriesService>();

    // Try by code first (most reliable), then by name
    final code = widget.countryCode?.trim();
    if (code != null && code.isNotEmpty) {
      try {
        return await service.fetchCountryByCode(code);
      } on RestCountriesException {
        // fallback to name search
      }
    }

    // Try the display name, then the English common name from cache
    try {
      return await service.fetchCountryByName(widget.countryName);
    } on RestCountriesException {
      final cached = provider.findCountryByName(widget.countryName);
      if (cached != null &&
          Country.normalizeText(cached.commonName) !=
              Country.normalizeText(widget.countryName)) {
        return service.fetchCountryByName(cached.commonName);
      }
      rethrow;
    }
  }

  void _retry() => setState(() => _countryFuture = _loadCountry());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8FC),
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: AppBar(
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF0D1B2A), Color(0xFF1B4DFF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          title: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.info_outline_rounded,
                  size: 18, color: Colors.white),
            ),
            const SizedBox(width: 10),
            const Text('Détails du pays'),
          ]),
        ),
      ),
      body: FutureBuilder<Country>(
        future: _countryFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
                child: CircularProgressIndicator(color: Color(0xFF1B4DFF)));
          }
          if (snapshot.hasError) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: AppErrorBanner(
                    message: snapshot.error.toString(), onRetry: _retry),
              ),
            );
          }
          return _CountryDetailsContent(country: snapshot.requireData);
        },
      ),
    );
  }
}

class _CountryDetailsContent extends StatelessWidget {
  const _CountryDetailsContent({required this.country});
  final Country country;

  @override
  Widget build(BuildContext context) {
    final fmt = NumberFormat.decimalPattern('fr_FR');

    return SingleChildScrollView(
      child: Column(children: [
        // Hero banner
        Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0D1B2A), Color(0xFF1B4DFF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 820),
                  child: Column(children: [
                    _FlagImage(country: country),
                    const SizedBox(height: 20),
                    Text(country.commonName,
                        textAlign: TextAlign.center,
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                height: 1.1,
                                letterSpacing: -0.5)),
                    if (_nativeName(country) != null) ...[
                      const SizedBox(height: 10),
                      Text(_nativeName(country)!,
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.rtl,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.85),
                                  fontWeight: FontWeight.w700,
                                  height: 1.2)),
                    ],
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(country.officialName,
                          textAlign: TextAlign.center,
                          style: Theme.of(context)
                              .textTheme
                              .titleSmall
                              ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.8),
                                  fontWeight: FontWeight.w600)),
                    ),
                  ]),
                ),
              ),
            ),
          ),
        ),

        // Info sections (#8: using InfoSection widget)
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 820),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
              child: Column(children: [
                _animatedSection(
                    0,
                    InfoSection(
                      title: 'Administration',
                      icon: Icons.account_balance_rounded,
                      rows: [
                        InfoRowData(
                            'Capitale',
                            _joinOrFallback(country.capitals),
                            Icons.location_city_rounded),
                        InfoRowData(
                            'Langues',
                            _joinOrFallback(country.languages.values.toList()),
                            Icons.translate_rounded),
                      ],
                    )),
                _animatedSection(
                    1,
                    InfoSection(
                      title: 'Géographie',
                      icon: Icons.terrain_rounded,
                      rows: [
                        InfoRowData('Région', _fallback(country.region),
                            Icons.map_rounded),
                        InfoRowData('Sous-région', _fallback(country.subregion),
                            Icons.explore_rounded),
                        InfoRowData(
                            'Superficie',
                            '${fmt.format(country.area.round())} km²',
                            Icons.straighten_rounded),
                        if (country.borders.isNotEmpty)
                          InfoRowData('Frontières', country.borders.join(', '),
                              Icons.border_all_rounded),
                      ],
                    )),
                _animatedSection(
                    2,
                    InfoSection(
                      title: 'Démographie',
                      icon: Icons.groups_rounded,
                      rows: [
                        InfoRowData(
                            'Population',
                            fmt.format(country.population),
                            Icons.people_alt_rounded),
                      ],
                    )),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _animatedSection(int index, Widget child) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + (index * 100)),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Opacity(
          opacity: value,
          child: Transform.translate(
              offset: Offset(0, 20 * (1 - value)), child: child)),
      child: child,
    );
  }

  String? _nativeName(Country country) {
    final n = country.nativeCommonName?.trim();
    if (n == null || n.isEmpty) return null;
    if (Country.normalizeText(n) == Country.normalizeText(country.commonName)) {
      return null;
    }
    return n;
  }

  String _joinOrFallback(List<String> values) {
    final clean = values.where((v) => v.trim().isNotEmpty).toList();
    return clean.isEmpty ? 'Non disponible' : clean.join(', ');
  }

  String _fallback(String v) => v.trim().isEmpty ? 'Non disponible' : v;
}

/// Flag image using CachedNetworkImage (#11)
class _FlagImage extends StatelessWidget {
  const _FlagImage({required this.country});
  final Country country;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(maxWidth: 520),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.15),
              blurRadius: 20,
              offset: const Offset(0, 6))
        ],
      ),
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: country.flagPngUrl.isEmpty
            ? const Icon(Icons.flag_rounded, size: 64)
            : ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: CachedNetworkImage(
                  imageUrl: country.flagPngUrl,
                  fit: BoxFit.contain,
                  placeholder: (context, url) => const Center(
                      child:
                          CircularProgressIndicator(color: Color(0xFF1B4DFF))),
                  errorWidget: (context, url, error) => const Center(
                      child: Icon(Icons.broken_image_rounded, size: 54)),
                ),
              ),
      ),
    );
  }
}
