import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/country.dart';
import '../models/visited_city.dart';
import '../providers/pays_provider.dart';
import '../widgets/app_error_banner.dart';
import '../widgets/visited_city_tile.dart';
import 'pays_details_page.dart';

class PaysPage extends StatefulWidget {
  const PaysPage({super.key});

  @override
  State<PaysPage> createState() => _PaysPageState();
}

class _PaysPageState extends State<PaysPage> {
  final _formKey = GlobalKey<FormState>();
  final _cityController = TextEditingController();
  final _searchController = TextEditingController();
  TextEditingController? _countryController;
  Country? _selectedCountry;
  String _searchQuery = '';

  @override
  void dispose() {
    _cityController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  List<VisitedCity> _filteredCities(List<VisitedCity> cities) {
    if (_searchQuery.isEmpty) return cities;
    final q = Country.normalizeText(_searchQuery);
    return cities
        .where((c) =>
            Country.normalizeText(c.cityName).contains(q) ||
            Country.normalizeText(c.countryName).contains(q))
        .toList();
  }

  Future<void> _saveCity(PaysProvider provider) async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;

    final country = _selectedCountry ??
        provider.findCountryByInput(_countryController?.text ?? '');
    if (country == null) {
      _showSnackBar('Choisissez un pays valide dans la liste.', isError: true);
      return;
    }

    try {
      await provider.addVisitedCity(
          cityName: _cityController.text, country: country);
      _cityController.clear();
      _countryController?.clear();
      setState(() => _selectedCountry = null);
      _showSnackBar('Ville sauvegardée avec succès ✓');
    } catch (error) {
      _showSnackBar(error.toString(), isError: true);
    }
  }

  Future<void> _confirmDelete(PaysProvider provider, VisitedCity city) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        icon: Container(
          width: 56,
          height: 56,
          decoration:
              BoxDecoration(color: Colors.red.shade50, shape: BoxShape.circle),
          child: Icon(Icons.delete_forever_rounded,
              color: Colors.red.shade600, size: 30),
        ),
        title: const Text('Supprimer la ville ?',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: Text(
            'Voulez-vous supprimer ${city.cityName}, ${city.countryName} ?',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Color(0xFF607089))),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          OutlinedButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            style: OutlinedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: const Text('Annuler'),
          ),
          const SizedBox(width: 8),
          FilledButton.icon(
            onPressed: () => Navigator.of(ctx).pop(true),
            icon: const Icon(Icons.delete_outline_rounded, size: 18),
            label: const Text('Supprimer'),
            style: FilledButton.styleFrom(
              backgroundColor: Colors.red.shade600,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
          ),
        ],
      ),
    );

    if (shouldDelete ?? false) {
      await provider.deleteVisitedCity(city);
      _showSnackBar('Ville supprimée.');
    }
  }

  void _openDetails(VisitedCity city) {
    Navigator.of(context).push(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 400),
        reverseTransitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (context, animation, secondaryAnimation) =>
            PaysDetailsPage(
          countryName: city.countryName,
          countryCode: city.countryCode,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final curved =
              CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
                .animate(curved),
            child: FadeTransition(opacity: curved, child: child),
          );
        },
      ),
    );
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Row(children: [
          Icon(
              isError
                  ? Icons.error_outline_rounded
                  : Icons.check_circle_outline_rounded,
              color: Colors.white,
              size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(message)),
        ]),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        backgroundColor:
            isError ? const Color(0xFFE53935) : const Color(0xFF00C9A7),
        margin: const EdgeInsets.all(16),
      ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: AppBar(
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF0D1B2A), Color(0xFF1B4DFF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          title: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.explore_rounded,
                  size: 20, color: Colors.white),
            ),
            const SizedBox(width: 10),
            const Text('Page Pays'),
          ]),
        ),
      ),
      body: SafeArea(
        child: Consumer<PaysProvider>(builder: (context, provider, _) {
          return RefreshIndicator(
            color: const Color(0xFF1B4DFF),
            onRefresh: provider.loadCountries,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              children: [
                Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 760),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _TopPanel(
                            cityCount: provider.visitedCities.length,
                            isLoadingCountries: provider.isLoadingCountries),
                        const SizedBox(height: 20),
                        if (provider.countriesError != null) ...[
                          AppErrorBanner(
                              message: provider.countriesError!,
                              onRetry: provider.loadCountries),
                          const SizedBox(height: 20),
                        ],
                        _VisitForm(
                          formKey: _formKey,
                          cityController: _cityController,
                          isSaving: provider.isSaving,
                          selectedCountry: _selectedCountry,
                          onCountrySelected: (c) =>
                              setState(() => _selectedCountry = c),
                          onCountryControllerReady: (c) =>
                              _countryController = c,
                          onCountryEdited: () {
                            if (_selectedCountry != null) {
                              setState(() => _selectedCountry = null);
                            }
                          },
                          onSave: () => _saveCity(provider),
                        ),
                        const SizedBox(height: 28),
                        _VisitedCitiesHeader(
                            count: provider.visitedCities.length),
                        const SizedBox(height: 12),
                        // Search bar (#1)
                        if (provider.visitedCities.length > 2)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 14),
                            child: TextField(
                              controller: _searchController,
                              onChanged: (v) =>
                                  setState(() => _searchQuery = v),
                              decoration: InputDecoration(
                                hintText: 'Rechercher une ville ou un pays...',
                                prefixIcon:
                                    const Icon(Icons.search_rounded, size: 20),
                                suffixIcon: _searchQuery.isNotEmpty
                                    ? IconButton(
                                        icon: const Icon(Icons.clear_rounded,
                                            size: 18),
                                        onPressed: () {
                                          _searchController.clear();
                                          setState(() => _searchQuery = '');
                                        },
                                      )
                                    : null,
                                filled: true,
                                fillColor: Colors.white,
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 12),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(14),
                                    borderSide: BorderSide.none),
                              ),
                            ),
                          ),
                        _VisitedCitiesList(
                          isLoading: provider.isLoadingVisitedCities,
                          cities: _filteredCities(provider.visitedCities),
                          onTap: _openDetails,
                          onDelete: (city) => _confirmDelete(provider, city),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// ─── Top Panel ──────────────────────────────────────────────
class _TopPanel extends StatelessWidget {
  const _TopPanel({required this.cityCount, required this.isLoadingCountries});
  final int cityCount;
  final bool isLoadingCountries;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0D1B2A), Color(0xFF1B4DFF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: const Color(0xFF1B4DFF).withValues(alpha: 0.3),
              blurRadius: 20,
              offset: const Offset(0, 8))
        ],
      ),
      child: Row(children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(14)),
          child:
              const Icon(Icons.public_rounded, color: Colors.white, size: 28),
        ),
        const SizedBox(width: 16),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Carnet de villes visitées',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.3)),
          const SizedBox(height: 6),
          Row(children: [
            const Icon(Icons.location_on_rounded,
                size: 14, color: Color(0xFF00C9A7)),
            const SizedBox(width: 4),
            Text(
              isLoadingCountries
                  ? 'Chargement des pays...'
                  : '$cityCount ville${cityCount > 1 ? 's' : ''} enregistrée${cityCount > 1 ? 's' : ''}',
              style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.8), fontSize: 13),
            ),
          ]),
        ])),
        if (isLoadingCountries)
          const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                  strokeWidth: 2.5, color: Color(0xFF00C9A7))),
      ]),
    );
  }
}

// ─── Visit Form ─────────────────────────────────────────────
class _VisitForm extends StatelessWidget {
  const _VisitForm({
    required this.formKey,
    required this.cityController,
    required this.isSaving,
    required this.selectedCountry,
    required this.onCountrySelected,
    required this.onCountryControllerReady,
    required this.onCountryEdited,
    required this.onSave,
  });

  final GlobalKey<FormState> formKey;
  final TextEditingController cityController;
  final bool isSaving;
  final Country? selectedCountry;
  final ValueChanged<Country> onCountrySelected;
  final ValueChanged<TextEditingController> onCountryControllerReady;
  final VoidCallback onCountryEdited;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PaysProvider>();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Form(
        key: formKey,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= 680;
            final countryField = _CountryAutocompleteField(
              provider: provider,
              onCountrySelected: onCountrySelected,
              onCountryControllerReady: onCountryControllerReady,
              onCountryEdited: onCountryEdited,
            );
            final cityField = _CityTextField(
              controller: cityController,
              onSave: onSave,
            );
            final saveButton = _SaveButton(
              isSaving: isSaving,
              onSave: onSave,
              compact: isWide && constraints.maxWidth < 780,
            );

            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1B4DFF).withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.add_location_alt_rounded,
                        color: Color(0xFF1B4DFF),
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Ajouter une ville',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF152033),
                          ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                if (isWide)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(flex: 5, child: countryField),
                      const SizedBox(width: 12),
                      Expanded(flex: 4, child: cityField),
                      const SizedBox(width: 12),
                      SizedBox(width: 170, child: saveButton),
                    ],
                  )
                else ...[
                  countryField,
                  const SizedBox(height: 14),
                  cityField,
                  const SizedBox(height: 16),
                  saveButton,
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}

class _CountryAutocompleteField extends StatelessWidget {
  const _CountryAutocompleteField({
    required this.provider,
    required this.onCountrySelected,
    required this.onCountryControllerReady,
    required this.onCountryEdited,
  });

  final PaysProvider provider;
  final ValueChanged<Country> onCountrySelected;
  final ValueChanged<TextEditingController> onCountryControllerReady;
  final VoidCallback onCountryEdited;

  @override
  Widget build(BuildContext context) {
    return Autocomplete<Country>(
      displayStringForOption: (country) => country.displayName,
      optionsBuilder: (value) {
        if (provider.isLoadingCountries) {
          return const Iterable<Country>.empty();
        }
        return provider.filterCountries(value.text);
      },
      onSelected: onCountrySelected,
      fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
        onCountryControllerReady(controller);
        return TextFormField(
          controller: controller,
          focusNode: focusNode,
          textInputAction: TextInputAction.next,
          onChanged: (_) => onCountryEdited(),
          validator: (value) {
            if (provider.countries.isEmpty) {
              return "La liste des pays n'est pas encore disponible.";
            }
            if (provider.findCountryByInput(value ?? '') == null) {
              return 'Sélectionnez un pays valide.';
            }
            return null;
          },
          decoration: InputDecoration(
            labelText: 'Pays',
            hintText: 'Ex. Tunisie',
            prefixIcon: const Icon(Icons.flag_rounded),
            suffixIcon: provider.isLoadingCountries
                ? const Padding(
                    padding: EdgeInsets.all(12),
                    child: SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  )
                : null,
          ),
        );
      },
      optionsViewBuilder: (context, onSelected, options) {
        final width = math.max(
          0.0,
          math.min(520.0, MediaQuery.sizeOf(context).width - 32),
        );
        return Align(
          alignment: Alignment.topLeft,
          child: Material(
            elevation: 8,
            shadowColor: Colors.black.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(14),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 280, maxWidth: 520),
              child: SizedBox(
                width: width,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: ListView.separated(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    itemCount: options.length,
                    separatorBuilder: (context, index) => Divider(
                      height: 1,
                      color: Colors.grey.shade100,
                    ),
                    itemBuilder: (context, index) {
                      final country = options.elementAt(index);
                      return ListTile(
                        dense: true,
                        leading: Icon(
                          Icons.flag_circle_rounded,
                          color: const Color(0xFF1B4DFF).withValues(alpha: 0.6),
                          size: 22,
                        ),
                        title: Text(
                          country.displayName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: country.displayName == country.commonName
                            ? null
                            : Text(
                                country.commonName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 12,
                                ),
                              ),
                        onTap: () => onSelected(country),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _CityTextField extends StatelessWidget {
  const _CityTextField({
    required this.controller,
    required this.onSave,
  });

  final TextEditingController controller;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      textCapitalization: TextCapitalization.words,
      textInputAction: TextInputAction.done,
      onFieldSubmitted: (_) => onSave(),
      validator: (value) {
        if (value == null || value.trim().isEmpty) {
          return 'Le nom de la ville est obligatoire.';
        }
        if (value.trim().length < 2) {
          return 'Le nom de la ville est trop court.';
        }
        return null;
      },
      decoration: const InputDecoration(
        labelText: 'Ville',
        hintText: 'Ex. Tunis',
        prefixIcon: Icon(Icons.location_city_rounded),
      ),
    );
  }
}

class _SaveButton extends StatelessWidget {
  const _SaveButton({
    required this.isSaving,
    required this.onSave,
    required this.compact,
  });

  final bool isSaving;
  final VoidCallback onSave;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      child: ElevatedButton.icon(
        onPressed: isSaving ? null : onSave,
        icon: isSaving
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
            : const Icon(Icons.add_rounded, size: 20),
        label: Text(compact ? 'Save' : 'Sauvegarder'),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF00C9A7),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
        ),
      ),
    );
  }
}

// ─── Visited Cities Header ──────────────────────────────────
class _VisitedCitiesHeader extends StatelessWidget {
  const _VisitedCitiesHeader({required this.count});
  final int count;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
            color: const Color(0xFF1B4DFF).withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(10)),
        child:
            const Icon(Icons.map_rounded, color: Color(0xFF1B4DFF), size: 20),
      ),
      const SizedBox(width: 10),
      Expanded(
          child: Text('Villes visitées',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: const Color(0xFF152033)))),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            const Color(0xFF1B4DFF).withValues(alpha: 0.1),
            const Color(0xFF00C9A7).withValues(alpha: 0.1),
          ]),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.location_on_rounded,
              size: 14, color: Color(0xFF1B4DFF)),
          const SizedBox(width: 4),
          Text('$count',
              style: const TextStyle(
                  color: Color(0xFF1B4DFF),
                  fontWeight: FontWeight.w900,
                  fontSize: 15)),
        ]),
      ),
    ]);
  }
}

// ─── Visited Cities List (with Dismissible) ─────────────────
class _VisitedCitiesList extends StatelessWidget {
  const _VisitedCitiesList({
    required this.isLoading,
    required this.cities,
    required this.onTap,
    required this.onDelete,
  });

  final bool isLoading;
  final List<VisitedCity> cities;
  final ValueChanged<VisitedCity> onTap;
  final ValueChanged<VisitedCity> onDelete;

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Padding(
          padding: EdgeInsets.all(40),
          child: Center(
              child: CircularProgressIndicator(color: Color(0xFF1B4DFF))));
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      switchInCurve: Curves.easeOut,
      switchOutCurve: Curves.easeIn,
      child: cities.isEmpty
          ? const _EmptyCitiesState()
          : ListView.separated(
              key: ValueKey(cities.map((c) => c.id).join(',')),
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: cities.length,
              separatorBuilder: (context, index) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final city = cities[index];
                return TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: Duration(milliseconds: 300 + (index * 60)),
                  curve: Curves.easeOutCubic,
                  builder: (context, value, child) => Opacity(
                    opacity: value,
                    child: Transform.translate(
                        offset: Offset(0, 16 * (1 - value)), child: child),
                  ),
                  child: Dismissible(
                    key: ValueKey(city.id),
                    direction: DismissDirection.endToStart,
                    confirmDismiss: (direction) async {
                      onDelete(city);
                      return false; // dialog handles deletion
                    },
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Icon(Icons.delete_outline_rounded,
                          color: Colors.red.shade500),
                    ),
                    child: VisitedCityTile(
                      city: city,
                      onTap: () => onTap(city),
                      onDelete: () => onDelete(city),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

// ─── Empty State ────────────────────────────────────────────
class _EmptyCitiesState extends StatelessWidget {
  const _EmptyCitiesState();

  @override
  Widget build(BuildContext context) {
    return Container(
      key: const ValueKey('empty-cities'),
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 20,
              offset: const Offset(0, 4))
        ],
      ),
      child: Column(children: [
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              const Color(0xFF1B4DFF).withValues(alpha: 0.1),
              const Color(0xFF00C9A7).withValues(alpha: 0.1),
            ], begin: Alignment.topLeft, end: Alignment.bottomRight),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.travel_explore_rounded,
              color: Color(0xFF1B4DFF), size: 36),
        ),
        const SizedBox(height: 16),
        Text('Aucune ville enregistrée',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w800, color: const Color(0xFF152033))),
        const SizedBox(height: 6),
        Text(
            'Ajoutez une ville et un pays pour commencer\nvotre carnet de voyage.',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(color: const Color(0xFF7B8BA5), height: 1.4)),
      ]),
    );
  }
}
